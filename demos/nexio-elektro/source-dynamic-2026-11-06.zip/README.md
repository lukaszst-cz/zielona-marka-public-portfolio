# NEXIO ELEKTRO, demo Zielona Marka

## Adres strony
https://nexio-elektro.vercel.app/

## Zawartość
- `index.html`: responsywna witryna demonstracyjnej marki NEXIO ELEKTRO.
- `assets/`: lokalne obrazy zastępcze, źródła zdjęć opisano w `photo-sources.json`.
- `nexio-dynamics.css`, `nexio-dynamics.js`: efekty i dostosowanie do paska.
- `manifest.webmanifest`, `service-worker.js`, `icons/`: instalacja PWA oraz podstawowy widok offline.
- `vercel.json`: konfiguracja Vercel.
- `PODGLAD-NEXIO.html`: wersja demonstracyjna do otwarcia lokalnie. PWA należy testować po HTTPS, nie w pliku lokalnym.

## Funkcje i zakres
Asortyment elektryczny, wyszukiwanie, wybór kategorii, lista materiałów do przygotowania zapytania, galeria materiałów, responsywna nawigacja, pełny zielony pasek Zielona Marka na dole strony, animacje przewijania.

**Zasady formularzy:** formularz NEXIO jedynie generuje tekst zapytania do skopiowania. Formularz Zielona Marka otwiera program pocztowy z przygotowaną wiadomością. Żaden z tych formularzy nie wysyła danych automatycznie na serwer.

**Zasady prezentacji:** NEXIO ELEKTRO jest marką fikcyjną. Produkty, zdjęcia, statystyki i opisy mają charakter poglądowy. Prawa do fotografii zewnętrznych należy zweryfikować przed wykorzystaniem komercyjnym. Brak integracji magazynowej, prawdziwej sprzedaży i płatności.

## Testowanie
Sprawdź menu, wyszukiwarkę, wybieranie kategorii, przygotowywanie i kopiowanie zapytania, rozwijanie i minimalizowanie zielonego paska, formularz Zielona Marka, widoki desktop i mobile. Instalację PWA i offline na rzeczywistych telefonach należy jeszcze potwierdzić.

## Zmiany dynamiczne, 06.11.2026

Interaktywne karty z efektem głębi i śledzeniem kursora, miniatury z podglądem i galerią, sterowanie klawiaturą, szybkie filtry, oznaczanie dopasowań w wyszukiwaniu, animowany stan dodawania kategorii, informacje zwrotne, aktywna nawigacja, animacje przewijania, objaśnienia w sekcjach B2B, wybór etapów zapytania, wskaźnik uzupełnienia formularza, reakcje ikon, pasek postępu czytania. Obsługa dotykowa i ograniczenia ruchu. Pełny panel Zielona Marka pozostawiono bez zmian. Brak nowych usług serwerowych.
