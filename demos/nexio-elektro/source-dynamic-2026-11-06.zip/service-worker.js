/* NEXIO ELEKTRO: podstawowe wsparcie pracy offline, pliki lokalne */
const CACHE_NAME = 'nexio-elektro-2026-11-06-v2';
const SHELL = ["/", "/index.html", "/nexio-dynamics.css", "/nexio-dynamics.js", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png", "/assets/aparatura.webp", "/assets/hero.webp", "/assets/kable.webp", "/assets/osprzet.webp", "/assets/pomiary.webp", "/assets/rozdzielnice.webp", "/assets/teletechnika.webp", "/assets/zm-foto/elektryka.webp", "/assets/zm-foto/oswietlenie.webp"];
self.addEventListener('install', event => {
 event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
 event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('nexio-elektro-') && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
 if (event.request.method !== 'GET') return;
 const url = new URL(event.request.url);
 if (url.origin !== self.location.origin) return;
 if (event.request.mode === 'navigate') {
  event.respondWith(fetch(event.request).then(response => {if(response.ok) {const copy=response.clone();caches.open(CACHE_NAME).then(c=>c.put(event.request, copy)).catch(()=>{});}return response;}).catch(() => caches.match(event.request).then(v=>v||caches.match('/index.html'))));
 } else {
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(c=>c.put(event.request,copy)).catch(()=>{});}return response;})));
 }
});
